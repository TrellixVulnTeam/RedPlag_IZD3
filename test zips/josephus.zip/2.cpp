#include <iostream>
using namespace std;
#define fastio ios_base::sync_with_stdio(0),cin.tie(0),cout.tie(0);


long long Josephus(long long n,long long k)
{
	if(n == 1)
	return 0;
	
	if(n < k)
	return (Josephus(n-1,k) + k) % n;
		
	long long n0 = n - (n/k),J_n0 = Josephus(n0,k);
	
	long long ans = J_n0 - (n % k);
	
	if(ans < 0)
		return (ans + n);
	else
		return (ans + ((ans / (k - 1))));
	return ans;
}


int main()
{
	fastio
	long long n,k;
	cin >> n >> k;
	
	long long ans = Josephus(n,k) + (long long)(1);
	cout << ans << "\n";
	
	return 0;
}
