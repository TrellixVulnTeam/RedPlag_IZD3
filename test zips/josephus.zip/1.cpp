#include <iostream>
using namespace std;

long long int J(long long int n, int k){
	if(n == 1) return 0;
	if(n < k) return (J(n-1,k)+ k)%n;
	long long int x = J(n-n/k,k);
	x = x - n%k;
	if(x<0) x += n;
	else x = x + x/(k-1);
	return x; 
}

int main(){
	long long int n;
	int k;
	cin >> n >> k;
	cout << J(n,k) + 1 << endl;
	return 0;	
}
