#include <iostream>
#include <string>
#include <math.h>
using namespace std;
#define fastio ios_base::sync_with_stdio(0),cin.tie(0),cout.tie(0);


const int MAXL = 100010;
const int MAXROOTL = 10000;
string str;
int k,L;
int alpha[MAXL];
int p[MAXROOTL];

int solve(int K,int len)
{
    int l = len/K;
    int freq[l][26], M[l];
    for(int i = 0; i < l; i++)
    {
        M[i] = 0;
        for(int j = 0; j < 26; j++)
            freq[i][j] = 0;
    }


    for(int i = 0; i < L; i++)
    {
        //int segment = i / l;
        int pos = i % l;
        freq[pos][alpha[i]]++;
        M[pos] = max(M[pos],freq[pos][alpha[i]]);
    }

    int ans = 0;
    for(int i = 0; i < l; i++)
    {
    	ans += (K - M[i]);
    }

    return ans;
}

int main()
{
    fastio
    cin >> str;
    cin >> k;
    L = str.length();
    for(int i = 0; i < L; i++)
        alpha[i] = (int)(str[i] - 'a');
    int ans = solve(k,L);
    cout << ans << "\n";


    int min_ans = ans, min_k = k,num_prime = 0;

    int tot = MAXL;
    bool prime[tot];
    int high = sqrt(tot);
    for(int i = 0; i < tot; i++)
    {
        prime[i] = true;
    }
    for(int i = 2; i <= high; i++)
    {
        if(!prime[i])
            continue;
        p[num_prime] = i;
        num_prime++;
        for(int j = i*i; j < tot; j+=i)
            prime[j] = false;
    }
    /*for(int i = (high + 1); i < tot; i++)
    {
    	if(!prime[i])
    	    continue;
    	p[num_prime] = i;
    	num_prime++;
    }*/
    int len = L;
    for(int i = 0; i <= min_ans; i++)
    {
    	int tmp_len = len;
        for(int j = 0; j < num_prime; j++)
        {
            if((len % p[j]) == 0)
            {
                int tmp_ans = solve(p[j],len);
                int tmp_k = p[j];
                if(tmp_ans < min_ans)
                {
                    min_ans = tmp_ans;
                    min_k = tmp_k;
                }
                else if(tmp_ans == min_ans)
                {
                    min_k = min(tmp_k,min_k);
                }
                while((tmp_len % p[j]) == 0)
                {
                	tmp_len /= p[j];
                }
                /*tmp_ans = solve(len/p[j],len);
                tmp_k = len/p[j];
                if(tmp_ans < min_ans)
                {
                    min_ans = tmp_ans;
                    min_k = tmp_k;
                }
                else if(tmp_ans == min_ans)
                {
                    min_k = min(tmp_k,min_k);
                }*/
                
            }	
        }
        if(tmp_len != 1)
        {
        	int tmp_ans = solve(tmp_len,len);
        	int tmp_k = tmp_len;
        	if(tmp_ans < min_ans)
        	{
        		min_ans = tmp_ans;
        		min_k = tmp_k;
        	}
        	else if(tmp_ans == min_ans)
        		min_k = min(min_k,tmp_len);
        }
        	
        len++;
    }

    cout << min_ans << " " << min_k << "\n";
    return 0;
}
