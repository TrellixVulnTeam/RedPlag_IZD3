#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
using namespace std;
#define fastio ios_base::sync_with_stdio(0),cin.tie(0),cout.tie(0);

struct T
{
    int a,b,ind;
    bool operator<(const T&q) const
    {
        return b < q.b;
    }
};

bool cmp_a(const T &p, const T &q)
{
    return p.a < q.a;
}

bool cmp(const T &p,const T &q)
{
    return (p.a != q.a) ? (p.a < q.a) : (p.b != q.b) ? (p.b < q.b) : (p.ind < q.ind);
}


int main()
{
    fastio
    int n;
    cin >> n;
    vector<T> A_tmp(n),C_tmp(n);

    for(int i = 0; i < n; i++)
    {
        cin >> A_tmp[i].a;
    }
    for(int i = 0; i < n; i++)
    {
        cin >> A_tmp[i].b;
        A_tmp[i].ind = i+1;
    }

    for(int i = 0; i < n; i++)
    {
        cin >> C_tmp[i].a;
    }
    for(int i = 0; i < n; i++)
    {
        cin >> C_tmp[i].b;
        C_tmp[i].ind = i+1;
    }

    sort(A_tmp.begin(),A_tmp.end(),cmp_a);
    sort(C_tmp.begin(),C_tmp.end(),cmp_a);
    bool possible = true, unique = true;

    vector<multiset<T> > A,C;
    for(int i = 0; i < n; i++)
    {
        if(i == 0 || A_tmp[i-1].a != A_tmp[i].a)    A.emplace_back();
        A.back().insert(A_tmp[i]);
    }
    for(int i = 0; i < n; i++)
    {
        if(i == 0 || C_tmp[i-1].a != C_tmp[i].a)    C.emplace_back();
        C.back().insert(C_tmp[i]);
    }

    vector<int> p,q;
    int x = 0, y = 0;
    while((p.size() < n))
    {
        if(!possible)
            break;

        if(min(A[x].size(),C[y].size()) > 1)
            unique = false;

        if(C[y].size() > A[x].size())
        {
            for(multiset<T>::iterator it = A[x].begin(); (it != A[x].end()) && possible; it++)
            {
                multiset<T>::iterator jt = C[y].upper_bound(*it);
                /*cout << it->a << " " << it->b << " " << it->ind << "\n";
                cout << jt->a << " " << jt->b << " " << jt->ind << "\n";
                cout << "\n";*/

                if(jt == C[y].begin())
                {
                    possible = false;
                    break;
                }
                jt--;
                /*cout << it->a << " " << it->b << " " << it->ind << "\n";
                cout << jt->a << " " << jt->b << " " << jt->ind << "\n";
                cout << "\n";*/

                p.push_back(it->ind);
                q.push_back(jt->ind);
                C[y].erase(jt);
            }
            x++;
            if(C[y].empty())
                y++;
        }
        else
        {
            for(multiset<T>::iterator it = C[y].begin(); (it != C[y].end()) && possible; it++)
            {
                multiset<T>::iterator jt = A[x].lower_bound(*it);
                /*cout << it->a << " " << it->b << " " << it->ind << "\n";
                cout << jt->a << " " << jt->b << " " << jt->ind << "\n";
                cout << "\n";*/

                if(jt == A[x].end())
                {
                    possible = false;
                    break;
                }
                /*cout << it->a << " " << it->b << " " << it->ind << "\n";
                cout << jt->a << " " << jt->b << " " << jt->ind << "\n";
                cout << "\n";*/

                p.push_back(jt->ind);
                q.push_back(it->ind);
                A[x].erase(jt);
            }
            y++;
            if(A[x].empty())
                x++;
        }

    }

    if(!possible)
    {
        cout << "impossible" << endl;
        return 0;
    }

    for(int i = 0; i < n; i++)
        cout << p[i] << " ";
    cout << "\n";
    for(int i = 0; i < n; i++)
        cout << q[i] << " ";
    cout << endl;



    if(!unique)
    {
        cout << "not unique" << endl;
        return 0;
    }

    /*A.clear();
    C.clear();
    reverse(A_tmp.begin(),A_tmp.end());
    reverse(C_tmp.begin(),C_tmp.end());

    for(int i = n - 1; i >= 0; i--)
    {
        if(i == (n-1) || A_tmp[i+1].a != A_tmp[i].a)    A.emplace_back();
        A.back().insert(A_tmp[i]);
    }

    for(int i = n - 1; i >= 0; i--)
    {
        if(i == (n-1) || C_tmp[i+1].a != C_tmp[i].a)    C.emplace_back();
        C.back().insert(C_tmp[i]);
    }*/


    A.clear();
    C.clear();
    for(int i = 0; i < n; i++)
    {
        if(i == 0 || A_tmp[i-1].a != A_tmp[i].a)    A.emplace_back();
        A.back().insert(A_tmp[i]);
    }
    for(int i = 0; i < n; i++)
    {
        if(i == 0 || C_tmp[i-1].a != C_tmp[i].a)    C.emplace_back();
        C.back().insert(C_tmp[i]);
    }

    vector<int> new_p, new_q;
    x = A.size() - 1;
    y = C.size() - 1;
    while(new_p.size() < n)
    {
        if(!possible)
            break;

        if(min(A[x].size(),C[y].size()) > 1)
            unique = false;
        if(!unique)
            break;

        if(A[x].size() <= C[y].size())
        {
            for(multiset<T>::iterator it = A[x].begin(); (it != A[x].end()) && possible; it++)
            {
                multiset<T>::iterator jt = C[y].upper_bound(*it);
                if(jt == C[y].begin())
                {
                    possible = false;
                    break;
                }
                jt--;
                new_p.push_back(it->ind);
                new_q.push_back(jt->ind);
                C[y].erase(jt);
            }
            x--;
            if(C[y].empty())
            {
                y--;
            }
        }
        else
        {
            for(multiset<T>::iterator it = C[y].begin(); (it != C[y].end()) && possible; it++)
            {
                multiset<T>::iterator jt = A[x].lower_bound(*it);
                if(jt == A[x].end())
                {
                    possible = false;
                    break;
                }
                new_p.push_back(jt->ind);
                new_q.push_back(it->ind);
                A[x].erase(jt);
            }
            y--;
            if(A[x].empty())
            {
                x--;
            }
        }
    }

    if(!possible)
    {
        cout << "unique" << endl;
        return 0;
    }

    if(!unique)
    {
        cout << "not unique" << endl;
        return 0;
    }

    for(int i = 0; (i < n) && unique; i++)
    {
        if((p[i] != new_p[n-1-i]) || (q[i] != new_q[n-1-i]))
        {
            unique = false;
            break;
        }
    }

    if(unique)
    {
        cout << "unique" << endl;
    }
    else
    {
        cout << "not unique" << endl;
    }


    return 0;
}
