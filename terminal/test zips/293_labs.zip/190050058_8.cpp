/** KAUSTUBH DIGHE **/ 
/** CS 293 A8 **/
#include <iostream>
#include <stack>
using namespace std;

struct Node {
	char Operator;
	int step, time, ops;
	Node *left, *right;
};

void stepTimeUnlimited(Node *et) {
	if(et->left==NULL && et->right==NULL) {                                                                                                                                                                                                                                                                              /** KAUSTUBH DIGHE **/ 
		et->step = 1;
		et->time = 1;
		return;
	}
	
	if(et->left==NULL){
		stepTimeUnlimited(et->right);
		if(et->right->Operator == et->Operator) {
			et->step = et->right->step;
			et->time = et->right->time;
			return;
		}
		et->step = et->right->step + 1;
		et->time = et->right->time + 1;
		return;
	}

	if(et->right==NULL){
		stepTimeUnlimited(et->left);
		if(et->left->Operator == et->Operator) {
			et->step = et->left->step;
			et->time = et->left->time;
			return; 
		}
		et->step = et->left->step + 1;
		et->time = et->left->time + 1;
		return;
	}

	stepTimeUnlimited(et->left);
	stepTimeUnlimited(et->right);
	
	char lop = et->left->Operator, rop = et->right->Operator;
	char op = et->Operator;
	if(op == lop && op == rop) {
		et->step = et->right->step + et->left->step - 1;
		et->time = max(et->left->time, et->right->time);
		return;
	}

	if(op == rop || op == lop) {
		et->step = et->right->step + et->left->step;
		et->time = max(et->left->time, et->right->time);
		if(et->left->time < et->right->time && op == lop) et->time += 1;
		if(et->right->time < et->left->time && op == rop) et->time += 1;
		return;
	}
	et->step = et->right->step + et->left->step + 1;
	et->time = max(et->left->time, et->right->time) + 1;
	return;
}

void stepLimited(Node *et, int k){
	if(et->left==NULL && et->right==NULL){
		et->step = 1;
		et->ops = 1;
		return;
	}

	if(et->right == NULL){
		stepLimited(et->left,k);
		if(et->Operator == et->left->Operator) {
			if(et->left->ops >= k-1){
				et->step = et->left->step + 1;
				et->ops = 1;
				return;
			}

			et->step = et->left->step;
			et->ops = et->left->ops + 1;
			return;
		}

		et->step = et->left->step + 1;
		et->ops = 1;
		return;		
	}

	if(et->left == NULL){
		stepLimited(et->right,k);
		if(et->Operator == et->right->Operator) {
			if(et->right->ops >= k-1){
				et->step = et->right->step + 1;
				et->ops = 1;
				return;
			}

			et->step = et->right->step;
			et->ops = et->right->ops + 1;
			return;
		}

		et->step = et->right->step + 1;
		et->ops = 1;
		return;		
	}

	stepLimited(et->left,k);
	stepLimited(et->right,k);
	char lop = et->left->Operator, rop = et->right->Operator;
	char op = et->Operator;
	if(op==lop && op==rop) {
		if(et->left->ops >= k-1 && et->right->ops >= k-1) {
			et->step = et->right->step + et->left->step + 1;
			et->ops = 1;
			return;
		}

		if(et->left->ops >= k-1) {
			et->step = et->right->step + et->left->step;
			et->ops = et->right->ops + 1;
			return;
		}

		if(et->right->ops >= k-1) {
			et->step = et->right->step + et->left->step;
			et->ops = et->left->ops + 1;
			return;
		}
		
		if(et->left->ops + et->right->ops >= k-1) {
			et->step = et->right->step + et->left->step;
			et->ops = min(et->left->ops,et->right->ops) + 1;
			return;
		}

		et->step = et->right->step + et->left->step - 1;
		et->ops = et->right->ops + et->left->ops + 1;
		return;
	}

	if(op == lop && et->left->ops < k-1) {
		et->step = et->right->step + et->left->step;
		et->ops = et->left->ops + 1;
		return;
	}

	if(op == rop && et->right->ops < k-1) {
		et->step = et->left->step + et->right->step;
		et->ops = et->right->ops + 1;
		return;
	}
	
	et->step = et->right->step + et->left->step + 1;
	et->ops = 1;
	return;
}

void timeLimited(Node *et, int k) {
	if(et->left==NULL && et->right==NULL){
		et->time = 1;
		et->ops = 1;
		return;
	}

	if(et->right == NULL){
		timeLimited(et->left,k);
		if(et->Operator == et->left->Operator) {
			if(et->left->ops >= k-1){
				et->time = et->left->time + 1;
				et->ops = 1;
				return;
			}

			et->time = et->left->time;
			et->ops = et->left->ops + 1;
			return;
		}

		et->time = et->left->time + 1;
		et->ops = 1;
		return;		
	}

	if(et->left == NULL){
		timeLimited(et->right,k);
		if(et->Operator == et->right->Operator) {
			if(et->right->ops >= k-1){
				et->time = et->right->time + 1;
				et->ops = 1;
				return;
			}

			et->time = et->right->time;
			et->ops = et->right->ops + 1;
			return;
		}

		et->time = et->right->time + 1;
		et->ops = 1;
		return;		
	}

	timeLimited(et->left,k);
	timeLimited(et->right,k);
	char lop = et->left->Operator, rop = et->right->Operator;
	char op = et->Operator;
	if(op==lop && op==rop) {
		if(et->left->time > et->right->time) {
			if(et->left->ops < k-1){
				et->time = et->left->time;
				et->ops = et->left->ops + 1;
				return;
			}
			et->time = et->left->time + 1;
			et->ops = 1;
			return;
		}
		if(et->left->time < et->right->time) {
			if(et->right->ops < k-1){
				et->time = et->right->time;
				et->ops = et->right->ops + 1;
				return;
			}
			et->time = et->right->time + 1;
			et->ops = 1;
			return;
		}
		if(et->right->ops + et->left->ops < k-1){
			et->time = et->right->time;
			et->ops = et->left->ops  + et->right->ops + 1;
			return;
		}
		et->time = et->right->time;
		et->ops = 1;
		return;
	}

	if(op == lop) {
		if(et->left->time > et->right->time){
			if(et->left->ops < k-1) {
				et->time = et->left->time;
				et->ops = et->left->ops + 1;
				return;
			}
			et->time = et->left->time + 1;
			et->ops = 1;
			return;
		}
		et->time = et->right->time + 1;
		et->ops = 1;
	}
	
	if(op == rop) {
		if(et->right->time > et->left->time){
			if(et->right->ops < k-1) {
				et->time = et->right->time;
				et->ops = et->right->ops + 1;
				return;
			}
			et->time = et->right->time + 1;
			et->ops = 1;
			return;
		}
		et->time = et->left->time + 1;
		et->ops = 1;
	}

	et->time = max(et->left->time, et->right->time) + 1;
	et->ops = 1;
	return;

}

int main() {
	string e; cin >> e;

	stack<Node *> s;
	for(int i=0; i<e.size(); i++){
		if(e[i] == 'e') {
			Node *n = new Node();
			n->Operator = 'e';
			n->step = -1; n->time = -1; n->ops = -1;
			n->left = NULL; n->right = NULL;
			s.push(n);
		}
		if(e[i] == '+' || e[i] == '*'){
			Node *n = new Node();
			n->Operator = e[i];
			n->left = NULL; n->right = NULL;
			n->step = -1; n->time = -1; n->ops = -1;
			if(!s.empty()){ 
				n->right = s.top();
				s.pop();
				if(n->right->Operator == 'e') n->right = NULL;
			}
			if(!s.empty()){ 
				n->left = s.top();
				s.pop();
				if(n->left->Operator == 'e') n->left = NULL;
			}
			s.push(n);
		}
	}

	Node *etree = s.top();
	stepTimeUnlimited(etree);
	cout << etree->step << ' ' << etree->time << endl;

	int t; cin >> t;
	while(t--){
		int k;
		cin >> k;
		stepLimited(etree,k);
		timeLimited(etree,k);
		cout << etree->step << ' ' << etree->time <<  endl; 
	}
	return 0;
}
