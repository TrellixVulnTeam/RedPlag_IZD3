#include <iostream>
using namespace std;

int main(){
	string s; cin >> s;
	int k; cin >> k;

	int primes[46] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199};

	int n = s.size();
	int m = n/k;

	int freqs[26][m];
	
	for(int i=0;i<26;i++) for(int j=0;j<m;j++) freqs[i][j] = 0;
	for(int i=0;i<n;i++) freqs[s[i] - 'a'][i%m] += 1;

	int min_replacements = 0;
	for(int i=0;i<m;i++) {
		int max_freq = freqs[0][i];
		for(int j=0;j<26;j++) if(max_freq < freqs[j][i]) max_freq = freqs[j][i];
		min_replacements += k - max_freq;
	}

	cout << min_replacements << endl;

	int min_ops = 1000000;
	int min_k = 100000;
	int u = min_replacements;

	for(int x=0; x<=min_ops; x++){
		int len = n+x;
		int tmp_len = len;
		for(int p=0;p<46;p++){
			while(tmp_len % primes[p] == 0) tmp_len /= primes[p];
			int k = primes[p];
			//if( k*k > len) break;
			if(len%k != 0) continue;
			int m = len/k; 
			///cout << k << " ";
			int freq[26][m];

			for(int i=0;i<26;i++) for(int j=0;j<m;j++) freq[i][j] = 0;
			for(int i=0;i<n;i++) freq[s[i] - 'a'][i%m] += 1;

			int min_replacements = 0;
			for(int i=0;i<m;i++) {
				int max_freq = freq[0][i];
				for(int j=0;j<26;j++) if(max_freq < freq[j][i]) max_freq = freq[j][i];
				min_replacements += k - max_freq;
			}
			if(min_replacements < min_ops){ min_ops = min_replacements; min_k = k;}
		}
		if(tmp_len != 1){
			k = tmp_len;
			int m = len/k; 
			
			int freq[26][m];

			for(int i=0;i<26;i++) for(int j=0;j<m;j++) freq[i][j] = 0;
			for(int i=0;i<n;i++) freq[s[i] - 'a'][i%m] += 1;

			int min_replacements = 0;
			for(int i=0;i<m;i++) {
				int max_freq = freq[0][i];
				for(int j=0;j<26;j++) if(max_freq < freq[j][i]) max_freq = freq[j][i];
				min_replacements += k - max_freq;
			}
			if(min_replacements < min_ops){ min_ops = min_replacements; min_k = k;}
		}
	}
			
	cout << min_ops << ' ' << min_k << endl;		
	return 0;
}
