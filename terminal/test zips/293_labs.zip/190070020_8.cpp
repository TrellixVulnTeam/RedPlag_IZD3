#include <iostream>
#include <string>
#include <stack>
#include <math.h>
using namespace std;
#define fastio ios_base::sync_with_stdio(0),cin.tie(0),cout.tie(0);


struct triple
{
    int a,b,c;
    triple()
    {
        a = b = c = 1;
    }
    triple(int A,int B,int C)
    {
        a = A;
        b = B;
        c = C;
    }
};

triple newTriple()
{
    triple t;
    t.a = t.b = t.c = 1;
    return t;
}

struct tree
{
    char op;
    //bool isLeaf;
    tree *left;
    tree *right;
    //int operands,time;
};

tree* newNode()
{
    tree* t = new tree;
    t->op = 'e';
    t->left = NULL;
    t->right = NULL;
    return t;
}

void compress(tree* t)
{
}

tree* constructTree(string &str)
{
    stack<tree*> s;
    for(int i = 0; i < str.length(); i++)
    {
        if(str[i] == 'e')
            s.push(newNode());
        else
        {
            tree* tmp = new tree;
            tmp->op = str[i];
            tmp->right = s.top();
            s.pop();
            tmp->left = s.top();
            s.pop();
            if(tmp->left->op == 'e'){
                    delete tmp->left;
                    tmp->left = NULL;
            }
            if(tmp->right->op == 'e'){
                delete tmp->right;
                tmp->right = NULL;
            }
            //compress(tmp);
            s.push(tmp);
        }
    }
    return s.top();
}

pair<int,int> solve(tree *t)
{
    // first = steps, second = time
    /*if(t == NULL)
        return make_pair(0,1);*/
    if(t->left == NULL && t->right == NULL)
        return make_pair(1,1);
    if(t->left == NULL)
    {
        if(t->right->op == t->op)
            return solve(t->right);
        pair<int,int> sr = solve(t->right);
        return make_pair(sr.first+1,sr.second+1);
    }
    if(t->right == NULL)
    {
        if(t->left->op == t->op)
            return solve(t->left);
        pair<int,int> sl = solve(t->left);
        return make_pair(sl.first+1,sl.second+1);
    }

    char l = t->left->op, r = t->right->op, ch = t->op;
    pair<int,int> sl = solve(t->left), sr = solve(t->right), cur;
    if((l == ch) && (r == ch))
    {
        cur.first = sl.first + sr.first - 1;
        cur.second = max(sl.second,sr.second);
    }
    else if(l == ch)
    {
        cur.first = sl.first + sr.first;
        cur.second = max(sl.second,sr.second+1);
    }
    else if(r == ch)
    {
        cur.first = sl.first + sr.first;
        cur.second = max(sl.second+1,sr.second);
    }
    else
    {
        cur.first = sl.first + sr.first + 1;
        cur.second = max(sl.second,sr.second) + 1;
    }
    return cur;
}


int solve_min_steps(tree *t,int &tmp,int k)
{
    if(t->left == NULL && t->right == NULL)
    {
        tmp = 1;
        return 1;
    }
    if(t->left == NULL)
    {
        int TMP;
        int sr = solve_min_steps(t->right,TMP,k);
        if(t->right->op == t->op)
        {
            if(TMP < k-1)
            {
                tmp = TMP + 1;
                return sr;
            }
            tmp = 1;
            return (sr + 1);
        }
        tmp = 1;
        return (sr + 1);
    }
    if(t->right == NULL)
    {
        int TMP;
        int sl = solve_min_steps(t->left,TMP,k);
        if(t->left->op == t->op){
        if(TMP < k - 1)
        {
            tmp = TMP + 1;
            return sl;
        }
        tmp = 1;
        return (sl + 1);}
        tmp = 1;
        return (sl + 1);
    }
    int ltmp,rtmp;
    int sl = solve_min_steps(t->left,ltmp,k);
    int sr = solve_min_steps(t->right,rtmp,k);
    char l = t->left->op, r = t->right->op, ch = t->op;
    if(l==ch && r==ch)
    {
        if(ltmp + rtmp < k - 1)
        {
            tmp = ltmp + rtmp + 1;
            return (sl + sr - 1);
        }
        if(min(ltmp,rtmp) < k - 1)
        {
            tmp = min(ltmp,rtmp) + 1;
            return sl + sr;
        }
        tmp = 1;
        return (sl + sr + 1);
    }
    if(ch == l)
    {
        if(ltmp < k - 1)
        {
            tmp = ltmp + 1;
            return (sl + sr);
        }
        tmp = 1;
        return (sl + sr + 1);
    }
    if(ch == r)
    {
        if(rtmp < k - 1)
        {
            tmp = rtmp + 1;
            return (sl + sr);
        }
        tmp = 1;
        return (sl + sr + 1);
    }
    tmp = 1;
    return (sl + sr + 1);
}

int solve_min_time(tree* t,int &tmp, int k)
{
    if(t->left == NULL && t->right==NULL)
    {
        tmp = 1;
        return 1;
    }
    if(t->left == NULL)
    {
        int rtmp;
        int sr = solve_min_time(t->right,rtmp,k);
        if(t->op == t->right->op)
        {
            if(rtmp < k - 1)
            {
                tmp = rtmp + 1;
                return sr;
            }
            tmp = 1;
            return sr + 1;
        }
        tmp = 1;
        return (sr + 1);
    }
    if(t->right == NULL)
    {
        int ltmp;
        int sl = solve_min_time(t->left,ltmp,k);
        if(t->op == t->left->op)
        {
            if(ltmp < k - 1)
            {
                tmp = ltmp + 1;
                return sl;
            }
            tmp = 1;
            return sl + 1;
        }
        tmp = 1;
        return sl + 1;
    }
    int ltmp,rtmp;
    int sl = solve_min_time(t->left,ltmp,k);
    int sr = solve_min_time(t->right,rtmp,k);
    char l = t->left->op, r = t->right->op, ch = t->op;
    if(l == ch && r == ch)
    {
        if(sl == sr)
        {
            if(ltmp + rtmp < k - 1)
            {
                tmp = ltmp + rtmp + 1;
                return sl;
            }
            tmp = 1;
            return sl + 1;
        }
        else if(sl <= sr)
        {
            if(rtmp < k - 1)
            {
                tmp = rtmp + 1;
                return sr;
            }
            tmp = 1;
            return sr + 1;
        }
        else
        {
            if(ltmp < k - 1)
            {
                tmp = ltmp + 1;
                return sl;
            }
            tmp = 1;
            return sl + 1;
        }
    }
    else if(r == ch)
    {
        if(sr <= sl)
        {
            tmp = 1;
            return sl + 1;
        }
        if(rtmp < k - 1)
        {
            tmp = rtmp + 1;
            return sr;
        }
        tmp = 1;
        return sr + 1;
    }
    else if(l == ch)
    {
        if(sl <= sr)
        {
            tmp = 1;
            return sr + 1;
        }
        if(ltmp < k - 1)
        {
            tmp = ltmp + 1;
            return sl;
        }
        tmp = 1;
        return sl + 1;
    }
    tmp = 1;
    return max(sl,sr) + 1;
}


int main()
{
    fastio
    string str;
    cin >> str;

    tree* T = constructTree(str);
    int k = (str.length() + 1)/2;
    pair<int,int> ans = solve(T);
    cout << ans.first << " " << ans.second << endl;

    int t;
    cin >> t;
    while(t--)
    {
        cin >> k;
        int tmp;
        cout << solve_min_steps(T,tmp,k) << " " << solve_min_time(T,tmp,k) << "\n";
    }
    return 0;
}
